/*
 * LWM_MSSY.c
 *
 * Created: 6.4.2017 15:42:46
 * Author : Krajsa
 */ 

#include <avr/io.h>
/*- Includes ---------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "config.h"
#include "hal.h"
#include "phy.h"
#include "sys.h"
#include "nwk.h"
#include "sysTimer.h"
#include "halBoard.h"
#include "halUart.h"
#include "main.h"
#include "makra.h"
#include "uart/uart.h"


/*- Definitions ------------------------------------------------------------*/
#ifdef NWK_ENABLE_SECURITY
#define APP_BUFFER_SIZE     (NWK_MAX_PAYLOAD_SIZE - NWK_SECURITY_MIC_SIZE)
#else
#define APP_BUFFER_SIZE     NWK_MAX_PAYLOAD_SIZE
#endif

/*- Types ------------------------------------------------------------------*/
typedef enum AppState_t
{
	APP_STATE_INITIAL,
	APP_STATE_IDLE,
} AppState_t;

/*- Prototypes -------------------------------------------------------------*/
static void appSendData(void);
void board_init();
/*- Variables --------------------------------------------------------------*/
static AppState_t appState = APP_STATE_INITIAL;
static SYS_Timer_t appTimer;
static NWK_DataReq_t appDataReq;
static bool appDataReqBusy = false;
static uint8_t appDataReqBuffer[APP_BUFFER_SIZE];
static uint8_t appUartBuffer[APP_BUFFER_SIZE];
static uint8_t appUartBufferPtr = 0;

/*- Implementations --------------------------------------------------------*/

FILE uart_str = FDEV_SETUP_STREAM(printCHAR, NULL, _FDEV_SETUP_RW);//soubor pro stdout

char text[]="label"; //= 'l''a''b''e''l''/0'


void board_init(){
	
	
	UART_init(38400); //baudrate 38400b/s
	
	UCSR1B |= (1 << RXCIE1);// UART receive interrupt enable
	//sbi(UCSR1B,RXCIE1);
	stdout = &uart_str; //standartn� v�stup/std output
	
}

// Inicializ�cia ADC
void adc_init() {
	// Nastavenie referen?n�ho nap�tia na 1.5V (intern� referen?n� zdroj)
	ADMUX = (1 << REFS1);  // REFS1 = 1 (VREF = 1.5V), REFS0 = 0 (VREF = 1.5V)
	
	// Povolenie ADC a nastavenie preddelova?a na 128
	ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

// ?�tanie hodnoty z ADC
uint16_t adc_read(uint8_t channel) {
	ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);  // V�ber kan�lu
	ADCSRA |= (1 << ADSC);  // Spustenie konverzie
	while (ADCSRA & (1 << ADSC));  // ?akaj na skon?enie konverzie
	return ADC;
}

/*************************************************************************//**
*****************************************************************************/
static void appDataConf(NWK_DataReq_t *req)
{
appDataReqBusy = false;
(void)req;
}

/*************************************************************************//**
*****************************************************************************/
static void appSendData(void)
{
if (appDataReqBusy || 0 == appUartBufferPtr)
return;

memcpy(appDataReqBuffer, appUartBuffer, appUartBufferPtr);

appDataReq.dstAddr = 1-APP_ADDR;
appDataReq.dstEndpoint = APP_ENDPOINT;
appDataReq.srcEndpoint = APP_ENDPOINT;
appDataReq.options = NWK_OPT_ENABLE_SECURITY;
appDataReq.data = appDataReqBuffer;
appDataReq.size = appUartBufferPtr;
appDataReq.confirm = appDataConf;
NWK_DataReq(&appDataReq);

appUartBufferPtr = 0;
appDataReqBusy = true;
}

/*************************************************************************//**
*****************************************************************************/
void HAL_UartBytesReceived(uint16_t bytes)
{
for (uint16_t i = 0; i < bytes; i++)
{
uint8_t byte = HAL_UartReadByte();

if (appUartBufferPtr == sizeof(appUartBuffer))
appSendData();

if (appUartBufferPtr < sizeof(appUartBuffer))
appUartBuffer[appUartBufferPtr++] = byte;
}

SYS_TimerStop(&appTimer);
SYS_TimerStart(&appTimer);
}

/*************************************************************************//**
*****************************************************************************/
static void appTimerHandler(SYS_Timer_t *timer)
{
appSendData();
(void)timer;
}

/*************************************************************************//**
*****************************************************************************/
static bool appDataInd(NWK_DataInd_t *ind)
{
for (uint8_t i = 0; i < ind->size; i++)
HAL_UartWriteByte(ind->data[i]);
return true;
}

/*************************************************************************//**
*****************************************************************************/
static void appInit(void)
{
NWK_SetAddr(APP_ADDR);
NWK_SetPanId(APP_PANID);
PHY_SetChannel(APP_CHANNEL);
#ifdef PHY_AT86RF212
PHY_SetBand(APP_BAND);
PHY_SetModulation(APP_MODULATION);
#endif
PHY_SetRxState(true);

NWK_OpenEndpoint(APP_ENDPOINT, appDataInd);

HAL_BoardInit();

appTimer.interval = APP_FLUSH_TIMER_INTERVAL;
appTimer.mode = SYS_TIMER_INTERVAL_MODE;
appTimer.handler = appTimerHandler;
}

/*************************************************************************//**
*****************************************************************************/
static void APP_TaskHandler(void)
{
switch (appState)
{
case APP_STATE_INITIAL:
{
appInit();
appState = APP_STATE_IDLE;
} break;

case APP_STATE_IDLE:
break;

default:
break;
}
}



/* Funkcia pre odoslanie ADC hodnoty cez LWM sie? */
static void send_adc_data(uint16_t adc_value) {
	// Skontroluj, ?i sa ADC hodnota zmenila alebo je potrebn� odosla?
	uint8_t adc_data[2];  // Budeme posiela? 2 bajty (16-bitov� hodnota)
	adc_data[0] = (uint8_t)(adc_value >> 8); // Horn� bajt
	adc_data[1] = (uint8_t)(adc_value & 0xFF); // Doln� bajt

	// Skop�ruj ADC hodnotu do po�iadavky na odoslanie
	memcpy(appDataReqBuffer, adc_data, sizeof(adc_data));
	appDataReq.size = sizeof(adc_data);
	
	// Nastav adresu druhej stanice a endpoint
	appDataReq.dstAddr = 1 - APP_ADDR;  // Cie?ov� adresa (druh� stanica)
	appDataReq.dstEndpoint = APP_ENDPOINT;
	appDataReq.srcEndpoint = APP_ENDPOINT;
	appDataReq.confirm = appDataConf;  // Funkcia na potvrdenie odoslania

	// Po�li d�ta cez sie?
	NWK_DataReq(&appDataReq);
}


/*************************************************************************//**
*****************************************************************************/
int main(void)
{
SYS_Init();

// Inicializ�cia UART
board_init();
adc_init();   // Inicializuj ADC

char buffer[32];
uint16_t adc_value;


HAL_UartInit(38400);
HAL_UartWriteByte('a');

UART_SendChar(27);//escape
UART_SendString("[2J");//clear and home
UART_SendChar(27);//escape
UART_SendString("[0;32;40m");//barva pozadi a textu

// Vytlac uv�taciu spr�vu
printf("-------------------------------------\n\r");
printf("Vitaj v programe pre snimanie obsadenia pomocou FSR senzora!\n\r");


while (1)
{
     SYS_TaskHandler();
     HAL_UartTaskHandler();
     APP_TaskHandler();

     // ?�tanie hodnoty z FSR senzora na kan�li 0 (PF0)
     uint16_t adc_value = adc_read(0);  // Kan�l 0 je priraden� k PF0 (ADC0)

     // Posielanie ADC hodnoty cez UART
     char buffer[32];
     snprintf(buffer, sizeof(buffer), "ADC Value: %u\n\r", adc_value);  // Form�tuj hodnotu
     UART_SendString(buffer);  // Po�li cez UART

     // Skontroluj, ?i je hodnota v�?�ia ako 100 (miesto je obsaden�)
     if (adc_value > 100) {
	     UART_SendString("Miesto je obsadene!\n\r");
	     } else {
	     UART_SendString("Miesto nie je obsadene.\n\r");
     }

     // Posielanie ADC hodnoty cez LWM sie?
     //send_adc_data(adc_value);

     _delay_ms(500);  // Po?kajte 500ms pred ?al��m ?�tan�m
     }
return 0;
}
